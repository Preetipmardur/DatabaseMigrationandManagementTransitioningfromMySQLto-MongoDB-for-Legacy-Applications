document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("migrationForm").addEventListener("submit", async function(event) {
        event.preventDefault();

        const mysqlHost = document.getElementById("mysqlHost").value;
        const mysqlUser = document.getElementById("mysqlUser").value;
        const mysqlPassword = document.getElementById("mysqlPassword").value;
        const mysqlDatabase = document.getElementById("mysqlDatabase").value;

        document.getElementById("result").innerText = "Migrating... Please wait.";

        try {
            const response = await fetch("/migrate", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ mysqlHost, mysqlUser, mysqlPassword, mysqlDatabase }),
            });

            const result = await response.json();
            document.getElementById("result").innerText = result.message;
        } catch (error) {
            document.getElementById("result").innerText = "Migration failed. Please try again.";
        }
    });
});
