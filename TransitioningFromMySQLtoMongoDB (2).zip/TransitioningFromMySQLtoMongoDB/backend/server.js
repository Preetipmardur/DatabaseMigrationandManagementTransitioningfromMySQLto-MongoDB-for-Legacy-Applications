const express = require("express");
const mysql = require("mysql2");
const { MongoClient } = require("mongodb");
const cors = require("cors");
require("dotenv").config();

const app = express();
const port = 5000;

app.use(express.json());
app.use(cors());

// MySQL Connection
const getMySQLConnection = (config) => {
    return mysql.createConnection({
        host: config.host,
        user: config.user,
        password: config.password,
        database: config.database,
    });
};

// MongoDB Connection
const mongoURI = "mongodb+srv://rjhr25469:<rjhr25469>@cluster0.gsk7h.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"; // Change if needed
const mongoDBName = "library_mgmt";

app.post("/migrate", async (req, res) => {
    const { mysqlHost, mysqlUser, mysqlPassword, mysqlDatabase } = req.body;

    const mysqlConnection = getMySQLConnection({
        host: mysqlHost,
        user: mysqlUser,
        password: mysqlPassword,
        database: mysqlDatabase,
    });

    mysqlConnection.connect((err) => {
        if (err) {
            return res.status(500).json({ message: "MySQL Connection Failed", error: err });
        }
    });

    const mongoClient = new MongoClient(mongoURI);
    try {
        await mongoClient.connect();
        const mongoDB = mongoClient.db(mongoDBName);

        // Example: Migrating Books Table
        mysqlConnection.query("SELECT * FROM books", async (err, books) => {
            if (err) {
                return res.status(500).json({ message: "Error Fetching Data from MySQL", error: err });
            }
            const booksCollection = mongoDB.collection("books");
            await booksCollection.insertMany(books);
        });

        res.json({ message: "Migration Completed Successfully" });
    } catch (error) {
        res.status(500).json({ message: "Migration Failed", error });
    } finally {
        mysqlConnection.end();
        mongoClient.close();
    }
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
