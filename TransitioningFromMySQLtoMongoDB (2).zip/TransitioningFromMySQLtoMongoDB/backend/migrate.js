require("dotenv").config();
const mysql = require("mysql2/promise");
const mongoose = require("mongoose");

// MySQL Connection
const mysqlPool = mysql.createPool({
    host: process.env.MYSQL_HOST,
    user: process.env.MYSQL_USER,
    password: process.env.MYSQL_PASSWORD,
    database: process.env.MYSQL_DATABASE,
});

// MongoDB Connection
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log("Connected to MongoDB"))
    .catch(err => console.error("MongoDB connection error:", err));

const db = mongoose.connection;

// Define MongoDB Schemas
const BranchSchema = new mongoose.Schema({
    branch_id: { type: String, unique: true },
    student_id: String,
    branch_address: String,
    contact_no: String,
});
const StudentSchema = new mongoose.Schema({
    stud_id: { type: String, unique: true },
    stud_name: String,
    branch_id: String,
    sem: Number,
    contact_no: String,
});
const BookSchema = new mongoose.Schema({
    book_id: { type: String, unique: true },
    book_title: String,
    rental_price: Number,
    status: String,
    author: String,
    publisher: String,
});
const MemberSchema = new mongoose.Schema({
    member_id: { type: String, unique: true },
    member_name: String,
    member_address: String,
    reg_date: Date,
});
const IssuedStatusSchema = new mongoose.Schema({
    issued_id: { type: String, unique: true },
    issued_member_id: String,
    issued_book_name: String,
    issued_date: Date,
    issued_book_id: String,
});
const ReturnStatusSchema = new mongoose.Schema({
    return_id: { type: String, unique: true },
    issued_id: String,
    return_book_name: String,
    return_date: Date,
    return_book_id: String,
});

// MongoDB Models
const Branch = mongoose.model("Branch", BranchSchema);
const Student = mongoose.model("Student", StudentSchema);
const Book = mongoose.model("Book", BookSchema);
const Member = mongoose.model("Member", MemberSchema);
const IssuedStatus = mongoose.model("IssuedStatus", IssuedStatusSchema);
const ReturnStatus = mongoose.model("ReturnStatus", ReturnStatusSchema);


// Define `migrateTable` Before Calling It
async function migrateTable(tableName, collection, primaryKey) {
    try {
        console.log(`Migrating table: ${tableName}...`);

        // Fetch data from MySQL
        const [rows] = await mysqlPool.execute(`SELECT * FROM ${tableName}`);

        if (rows.length > 0) {
            // Insert data into MongoDB
            await collection.insertMany(rows);
            console.log(`${tableName} migration completed.`);
        } else {
            console.log(` ${tableName} is empty. No data migrated.`);
        }
    } catch (error) {
        console.error(` Error migrating ${tableName}:`, error);
    }
}

//  Migrate Data Function
async function migrateData() {
    console.log(" Starting Migration Process...");

    await migrateTable("branch", Branch, "branch_id");
    await migrateTable("students", Student, "stud_id");
    await migrateTable("books", Book, "book_id");
    await migrateTable("members", Member, "member_id");
    await migrateTable("issued_status", IssuedStatus, "issued_id");
    await migrateTable("return_status", ReturnStatus, "return_id");

    console.log(" Migration completed successfully!");

    // Close connections properly
    await mysqlPool.end();
    mongoose.connection.close();
}

// Start Migration
migrateData();
