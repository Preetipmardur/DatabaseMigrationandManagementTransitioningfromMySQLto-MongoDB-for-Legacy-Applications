require("dotenv").config();
const mongoose = require("mongoose");

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });

const db = mongoose.connection;
db.on("error", console.error.bind(console, "MongoDB connection error:"));

db.once("open", async () => {
    console.log("Connected to MongoDB");

    const collections = [
        { name: "students", uniqueField: "stud_id" },
        { name: "branch", uniqueField: "branch_id" },
        { name: "books", uniqueField: "book_id" },
        { name: "members", uniqueField: "member_id" },
        { name: "issued_status", uniqueField: "issued_id" },
        { name: "return_status", uniqueField: "return_id" },
    ];

    for (const { name, uniqueField } of collections) {
        const collection = db.collection(name);
        
        // Step 1: Find Duplicates
        const duplicates = await collection.aggregate([
            {
                $group: {
                    _id: { [uniqueField]: `$${uniqueField}` },
                    duplicateIds: { $push: "$_id" },
                    count: { $sum: 1 }
                }
            },
            { $match: { count: { $gt: 1 } } }
        ]).toArray();

        // Step 2: Remove Duplicates (Keep One, Delete Others)
        for (const doc of duplicates) {
            doc.duplicateIds.shift(); // Keep one, delete others
            await collection.deleteMany({ _id: { $in: doc.duplicateIds } });
        }

        console.log(`Duplicates removed from ${name}!`);

        // Step 3: Verify if any duplicates remain
        const remainingDuplicates = await collection.aggregate([
            { $group: { _id: `$${uniqueField}`, count: { $sum: 1 } } },
            { $match: { count: { $gt: 1 } } }
        ]).toArray();

        if (remainingDuplicates.length === 0) {
            console.log(`No duplicates found in ${name}!`);
        } else {
            console.log(`Duplicates still exist in ${name}:`, remainingDuplicates);
        }

        // Step 4: Create Unique Index to Prevent Future Duplicates
        try {
            await collection.createIndex({ [uniqueField]: 1 }, { unique: true });
            console.log(` Unique index created for ${uniqueField} in ${name}`);
        } catch (err) {
            console.error(`Error creating index for ${name}:`, err.message);
        }
    }

    mongoose.connection.close();
});
